---
AIGC:
  ContentProducer: '001191110102MAD55U9H0F10002'
  ContentPropagator: '001191110102MAD55U9H0F10002'
  Label: '1'
  ProduceID: '753cbacf-3cf5-46a9-bfd1-e60b1537f9ff'
  PropagateID: '753cbacf-3cf5-46a9-bfd1-e60b1537f9ff'
  ReservedCode1: '347b0d70-34d8-4145-b885-896fbdf16046'
  ReservedCode2: '347b0d70-34d8-4145-b885-896fbdf16046'
---

# 运维监控查询示例

## 示例 1：查询业务系统下的资源

用户问题：

`查一下测试系统下的 linux 主机资源`

处理步骤：

1. 将“测试”作为业务系统资源名称关键词
2. 将“linux 主机”映射为 `classKeys=["linux"]`
3. 调用 `cmdb.resources.search` 查询业务系统候选，条件为 `resourceNameKeywords=["测试"]`、`classKeys=["business_application"]`，且不传 `monitorOnly`
4. 用户确认候选后，取候选返回的 `neId` 作为 `busiSysId`
5. 调用 `cmdb.resources.by_business_system` 查询资源列表

确认业务系统后的查询条件示例：

```json
{
  "busiSysIds": ["确认后的业务系统资源ID"],
  "classKeys": ["linux"],
  "monitorOnly": true,
  "current": 1,
  "size": 20
}
```

## 示例 2：查询业务系统下主机资源总数

用户问题：

`测试系统下面有多少台主机`

处理步骤：

1. 将“测试”作为业务系统资源名称关键词
2. “主机”默认映射为 `classKeys=["linux","windows","host_machine"]`
3. 先调用 `cmdb.resources.search` 查询并确认业务系统，条件为 `resourceNameKeywords=["测试"]`、`classKeys=["business_application"]`，且不传 `monitorOnly`
4. 再调用 `cmdb.resources.by_business_system`
5. 使用分页结果中的 `total` 作为资源总数

## 示例 3：看业务系统当前告警总数和等级分布

用户问题：

`看一下测试系统最近 24 小时的当前告警总数和等级分布`

处理步骤：

1. 先查询并确认“测试系统”
2. 确认后记录 `busiSysId=候选.neId`
3. 时间范围使用最近 24 小时
4. 调用 `alarms.summary`

整理后的条件示例：

```json
{
  "busiSysIds": ["确认后的业务系统资源ID"],
  "classKeys": ["linux", "windows", "host_machine"],
  "startTime": "当前时间-24小时",
  "endTime": "当前时间"
}
```

## 示例 4：看告警最多的主机

用户问题：

`查测试系统最近 24 小时告警最多的 5 台主机`

处理步骤：

1. 先查询并确认“测试系统”
2. “主机”默认映射为 `classKeys=["linux","windows","host_machine"]`
3. 调用 `alarms.top_resources`
4. `topN=5`

## 示例 5：看某台主机的指标趋势

用户问题：

`看下 10.11.0.151 这台主机的磁盘使用率趋势`

处理步骤：

1. 判断 `10.11.0.151` 符合 IP 格式，作为 `ip`
2. 调用 `cmdb.resources.search` 查询并确认主机资源
3. 调用 `metrics.info`，用“磁盘使用率”查询指标候选
4. 用户确认指标后，调用 `metrics.trend`
5. 如果用户未指定时间，默认最近 1 小时

趋势查询条件示例：

```json
{
  "instanceName": "确认后的主机资源ID",
  "metric": "确认后的指标key",
  "startTime": "当前时间-1小时",
  "endTime": "当前时间"
}
```

## 示例 6：看实例类型支持哪些指标

用户问题：

`linux 主机有哪些磁盘相关指标`

工具选择：

- `metrics.info`

整理后的条件：

```json
{
  "instanceType": "linux",
  "metricKeywords": ["磁盘"]
}
```

## 示例 7：按主机名片段查询主机

用户问题：

`查一下 app01 这台主机的告警`

处理步骤：

1. 将 `app01` 作为 `resourceNameKeywords`
2. “主机”默认映射为 `classKeys=["linux","windows","host_machine"]`
3. 调用 `cmdb.resources.search` 查询候选主机
4. 用户确认后记录 `neId`
5. 再调用 `alarms.page` 查询该主机告警

> AI生成