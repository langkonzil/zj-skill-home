---
AIGC:
  ContentProducer: '001191110102MAD55U9H0F10002'
  ContentPropagator: '001191110102MAD55U9H0F10002'
  Label: '1'
  ProduceID: '072f0cd4-050a-43ca-b6c5-e378efb803ab'
  PropagateID: '072f0cd4-050a-43ca-b6c5-e378efb803ab'
  ReservedCode1: '8204cbbe-cb8c-43f1-b468-797a8bcaa219'
  ReservedCode2: '8204cbbe-cb8c-43f1-b468-797a8bcaa219'
---

# 运维监控查询规则

## 1. 通用字段归一化

- `busiSysNameKeywords`：资源侧业务系统名称关键字列表，适用于按资源 tags 中挂载的业务系统名称过滤资源
- `busiSysIds`：业务系统 ID 列表，适用于按业务系统查资源和告警查询
- `classKeys`：资源类型列表，如 `linux`
- `resourceNameKeywords`：资源名称关键字列表，多个关键字按“或”匹配
- `ip`：资源 IP，按精确匹配处理
- `monitorOnly`：是否只查监控开启资源；不传表示不过滤监控状态
- `tags`：指标标签键值对，如 `device`、`host_ip`

## 2. 时间口径

- 时间字段统一为 `yyyy-MM-dd HH:mm:ss`
- 时间范围统一按 `[startTime, endTime)` 理解
- 只要工具调用涉及时间范围，就同时提供 `startTime` 和 `endTime`

## 3. 告警查询口径

- 告警汇总默认统计当前告警，统一传 `alarmState = 0`
- 告警 Top 资源和告警列表在当前设计中也按当前告警口径组织
- 如果用户明确要求“历史告警”或“全部状态告警”，先检查当前工具能力是否已支持；若未支持，先说明限制

## 4. 资源查询口径

- 资源查询优先限制范围，不要无条件全量查询
- 用户通常不会知道业务系统 ID 或资源 ID，不要要求用户直接提供 ID
- 如果用户给了业务系统名称或名称片段，先用 `cmdb.resources.search` 查询业务系统候选，查询条件固定为 `resourceNameKeywords + classKeys=["business_application"]`
- 查询业务系统本体时不要传 `monitorOnly`，这样监控开启和未开启两种状态都能查到
- 不要用 `busiSysNameKeywords` 作为业务系统候选确认的主条件
- 用户确认业务系统候选后，记录候选返回的 `neId` 作为 `busiSysId`
- 业务系统确认后，后续资源、告警和统计查询只使用 `busiSysIds` 锁定系统范围，不再叠加业务系统名称关键词
- 只有上下文中已经确认过业务系统 ID 时，才直接用 `cmdb.resources.by_business_system`
- 用户说“主机”时，默认映射为 `classKeys=["linux","windows","host_machine"]`
- 用户说“linux 主机”时，映射为 `classKeys=["linux"]`
- 用户说“windows 主机”时，映射为 `classKeys=["windows"]`
- 用户明确说“主机名/名称包含 xxx”时，才使用 `resourceNameKeywords`
- 用户给出标准 IPv4 格式时，优先映射为 `ip`
- 用户给出的内容不像标准 IP 时，优先作为 `resourceNameKeywords` 查询候选
- 如果用户把疑似 IP 当成主机名描述，且格式不符合标准 IPv4，不要强行映射为 `ip`

## 5. 指标查询口径

- 指标趋势和指标最新值优先要求 `instanceName`、`metric`
- `tags` 为可选增强过滤条件，常见键包括 `device`、`host_ip`
- 用户通常不会知道 `instanceName`，需要先通过资源搜索确认资源，取候选返回的 `neId` 作为 `instanceName`
- 用户要“趋势”时使用 `metrics.trend`
- 用户要“最新值”时使用 `metrics.current`
- 用户要“指标定义”时使用 `metrics.info`
- 当指标存在多个对象标签值且用户未明确指定对象时，使用 `metrics.tag_options`
- `metrics.tag_options` 用于让用户确认 `filesystem`、`device`、`interface` 这类对象型标签，不要把通用 tags 直接给用户

## 6. 最少补问原则

仅在缺少阻塞查询的关键字段时补问：

- `cmdb.resources.search`：至少需要 `busiSysNameKeywords`、`resourceNameKeywords`、`ip` 中的一类有效条件；确认业务系统本体时必须使用 `resourceNameKeywords + classKeys=["business_application"]`，且不要传 `monitorOnly`
- `cmdb.resources.by_business_system`：至少需要已确认的 `busiSysIds`
- `alarms.summary`、`alarms.top_resources`、`alarms.page`：优先需要 `busiSysIds + startTime + endTime`
- `metrics.trend`、`metrics.current`：至少需要已确认的 `instanceName + metric + startTime + endTime`
- `metrics.tag_options`：至少需要已确认的 `instanceName + metric + startTime + endTime`
- `metrics.info`：至少需要 `instanceType`

## 7. 输出组织规则

- 先说明本次使用的 MCP 工具
- 再说明整理后的查询条件
- 汇总类问题先给结论，明细类问题再给记录
- 结果为空时直接说明“未查到匹配数据”
- 回答语言默认中文

> AI生成