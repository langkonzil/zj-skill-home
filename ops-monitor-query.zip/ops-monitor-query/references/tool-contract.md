---
AIGC:
  ContentProducer: '001191110102MAD55U9H0F10002'
  ContentPropagator: '001191110102MAD55U9H0F10002'
  Label: '1'
  ProduceID: 'c4993a02-fd49-472c-944f-6144e32dbb1f'
  PropagateID: 'c4993a02-fd49-472c-944f-6144e32dbb1f'
  ReservedCode1: '1752d521-1ec8-4116-ae0a-dd4ba3d54bdc'
  ReservedCode2: '1752d521-1ec8-4116-ae0a-dd4ba3d54bdc'
---

# 运维监控查询工具清单

本文档提炼自项目监控查询能力说明，供智能体快速选择项目 MCP 工具使用。

## 1. CMDB 资源模糊查询

- MCP 工具：`cmdb.resources.search`
- 适用场景：按资源名称关键字、业务系统资源名称关键字、IP、资源类型查询资源；确认业务系统本体时必须固定 `classKeys=["business_application"]`，且不要传 `monitorOnly`

关键参数：

- `busiSysNameKeywords`
- `resourceNameKeywords`
- `ip`
- `classKeys`
- `monitorOnly`
- `current`
- `size`

返回重点：

- `records`
- `total`

业务系统候选确认规则：

- 用户查询具体业务系统时，传 `resourceNameKeywords=["业务系统名称关键词"]`
- 固定传 `classKeys=["business_application"]`
- 不传 `monitorOnly`
- 不使用 `busiSysNameKeywords` 作为业务系统候选确认的主条件
- 查询业务系统本体时不要传 `monitorOnly`，这样监控开启和未开启两种状态都能查到
- 用户确认候选后，取返回的 `neId` 作为后续 `busiSysIds`

## 2. 按已确认业务系统查询资源

- MCP 工具：`cmdb.resources.by_business_system`
- 适用场景：按已确认业务系统 ID 查询资源列表及总数；业务系统 ID 来自候选确认结果，不要求用户直接提供

关键参数：

- `busiSysIds`
- `classKeys`
- `resourceNameKeywords`
- `ip`
- `monitorOnly`
- `current`
- `size`

返回重点：

- `records`
- `total`

## 3. 告警汇总

- MCP 工具：`alarms.summary`
- 适用场景：查询告警概况汇总，包括未恢复告警数、已恢复告警数、有告警资源数和等级分布

关键参数：

- `busiSysIds`
- `classKeys`
- `resourceNameKeywords`
- `ip`
- `startTime`
- `endTime`

返回重点：

- `activeAlarmCount`
- `recoveredAlarmCount`
- `affectedResourceCount`
- `levelStats`

## 4. 告警 Top 资源

- MCP 工具：`alarms.top_resources`
- 适用场景：查询指定条件下告警数量最多的资源

关键参数：

- `busiSysIds`
- `classKeys`
- `resourceNameKeywords`
- `ip`
- `alarmState`
- `startTime`
- `endTime`
- `topN`

返回重点：

- `neId`
- `neName`
- `ip`
- `count`

## 5. 告警分页列表

- MCP 工具：`alarms.page`
- 适用场景：分页查询告警明细

关键参数：

- `busiSysIds`
- `classKeys`
- `resourceNameKeywords`
- `ip`
- `alarmState`
- `startTime`
- `endTime`
- `current`
- `size`

返回重点：

- `records`
- `total`

## 6. 指标趋势

- MCP 工具：`metrics.trend`
- 适用场景：查询某个指标在指定时间范围内的时序数据

关键参数：

- `instanceName`
- `metric`
- `tags`
- `startTime`
- `endTime`

返回重点：

- `timestamp`
- `instanceName`
- `metric`
- `value`

## 7. 指标最新值

- MCP 工具：`metrics.current`
- 适用场景：查询某个指标在指定时间范围内的最新值和峰值

关键参数：

- `instanceName`
- `metric`
- `tags`
- `startTime`
- `endTime`

返回重点：

- `latestTimestamp`
- `currentValue`
- `peakValue`
- `avgValue`
- `minValue`

## 8. 指标对象标签候选查询

- MCP 工具：`metrics.tag_options`
- 适用场景：当指标带对象标签且用户未明确指定对象时，查询该资源该指标在指定时间范围内可选的对象标签和值，例如 `filesystem`、`device`、`interface`

关键参数：

- `instanceName`
- `metric`
- `tags`
- `startTime`
- `endTime`

返回重点：

- `tagKey`
- `tagLabel`
- `values`

过滤规则：

- `__` 前缀通用 tags 不返回
- `agent_ip`、`collect_hostname`、`collect_ip`、`configtype`、`host_ip`、`instance_name`、`job`、`metric_type`、`monitor`、`plugin_id`、`plugin_name`、`resourceGroup`、`type` 这些通用 tags 不返回
- 只把过滤后的对象型标签返回给用户选择

## 9. 指标信息查询

- MCP 工具：`metrics.info`
- 适用场景：查询某类实例支持的指标定义，可按指标 key 精确过滤，也可按指标 key 或指标名称片段模糊匹配

关键参数：

- `instanceType`
- `metricName`
- `metricKeyword`
- `metricKeywords`

返回重点：

- `metricName`
- `metricLabel`

> AI生成