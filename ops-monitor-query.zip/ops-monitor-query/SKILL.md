---
name: ops-monitor-query
description: 当用户希望查询运维监控系统中的 CMDB 资源、当前告警、告警汇总、告警 Top 资源、指标趋势、指标当前值或指标定义时使用。该技能帮助智能体选择正确工具、补齐筛选条件并按统一口径组织结果。
---

# 运维监控查询技能

## 适用场景

当用户提出以下类型的问题时，使用本技能：

- 查询 CMDB 资源
- 查询某个业务系统下的资源
- 查询当前告警总数、等级分布、告警 Top 资源、告警列表
- 查询指标趋势
- 查询某个指标在指定时间范围内的最新值
- 查询某种实例类型下支持的指标定义

## 使用原则

- 优先使用项目已提供的 MCP 工具，不直接重写 SQL。
- 先判断用户意图属于 `cmdb`、`alarm` 还是 `metric`。
- 先抽取筛选条件，再决定调用哪个工具。
- 只有在缺少关键参数且无法合理补全时，才向用户追问最少的问题。

## MCP 工具调用约束

- 统一使用项目已注册的 MCP 工具，不直接拼接 HTTP 地址。
- 不绕过项目工具直接访问数据库。
- 当前工具包括：
  - `cmdb.resources.search`
  - `cmdb.resources.by_business_system`
  - `alarms.summary`
  - `alarms.top_resources`
  - `alarms.page`
  - `metrics.info`
  - `metrics.tag_options`
  - `metrics.current`
  - `metrics.trend`

## 工具选择规则

- 用户要“按业务系统名称模糊查资源”，使用 `cmdb.resources.search`
- 用户要“按已确认业务系统查资源”，使用 `cmdb.resources.by_business_system`
- 用户要“看当前告警总数和等级分布”，使用 `alarms.summary`
- 用户要“看告警最多的资源”，使用 `alarms.top_resources`
- 用户要“看告警明细列表”，使用 `alarms.page`
- 用户要“看指标趋势”，使用 `metrics.trend`
- 用户要“看某个指标在某段时间内的最新值或峰值”，使用 `metrics.current`
- 用户要“看某类实例有哪些指标”，使用 `metrics.info`
- 用户要“确认某个指标的对象标签，例如文件系统、磁盘、网卡、挂载点”，使用 `metrics.tag_options`

详细工具说明见：

- `references/tool-contract.md`
- `references/query-rules.md`
- `references/examples.md`

## 参数归一化要求

- 资源名称关键字统一映射为 `resourceNameKeywords`
- 查询业务系统本体时，业务系统名称关键字统一映射为 `resourceNameKeywords`，并固定 `classKeys=["business_application"]`
- `busiSysNameKeywords` 仅用于资源侧按挂载业务系统名称过滤，不用于确认业务系统本体
- 业务系统 ID 列表统一映射为 `busiSysIds`
- 资源类型统一映射为 `classKeys`
- IP 按精确匹配，统一映射为 `ip`
- 时间范围统一使用 `startTime` 和 `endTime`
- 指标标签统一整理为 `tags` 键值对

## 固定口径

- 资源和告警相关查询支持 `classKeys`、`resourceNameKeywords`、`ip`
- 查询具体业务系统候选时固定 `classKeys=["business_application"]`，确认后取候选 `neId` 作为 `busiSysId`
- 业务系统确认后，后续查询使用 `busiSysIds` 锁定范围，不再叠加业务系统名称关键词
- 查询业务系统本体时不要传 `monitorOnly`
- 普通资源查询如果只看监控开启资源，需要显式传 `monitorOnly = true`
- `alarms.summary` 返回未恢复告警数、已恢复告警数、有告警资源数
- `alarms.summary` 的 `levelStats` 固定按 `alarm_state = 0` 统计
- 时间范围统一按 `[startTime, endTime)` 理解
- 指标查询优先要求 `instanceName + metric`，标签条件按需补充

## 输出要求

- 先返回结论，再返回明细
- 默认不展示任何内部 ID 或内部主键，例如 `busiSysId`、`neId`、`alarmId`、`instanceName`；只展示名称、IP、类型、时间和统计结果
- 内部 ID 只用于上下文和工具调用，除非用户明确要求查看原始标识，否则不回显
- 统计类结果优先使用图表展示，表格和文字明细作为补充
- 如果运行环境不适合图表展示，降级为表格、列表和文字摘要
- 告警等级分布优先使用柱状图或饼图展示
- 告警最多资源 TopN 优先使用横向柱状图展示
- 指标趋势必须使用折线图展示；只有运行环境不支持图表时，才降级为趋势数据表和文字摘要
- 无数据时明确说明“当前条件下未查到匹配结果”
- 回答以中文为主，字段名保留工具返回的原字段名

## 注意事项

- 如果用户只给了模糊意图，不要一次追问很多字段，只补问阻塞查询的最小信息
- 如果用户要的是汇总结果，不要默认返回完整明细列表
- 如果用户明确要分页列表，优先使用分页工具
- 如果用户描述与工具能力不一致，先按最接近的能力解释限制，再组织调用方案
